/* 11/1/09	Misc. functions */

/* prototypes **********/
void delay(uint16 value);
void delays(void);

/* routines begin *********/
void delay(uint16 value) {
  for (;value; value--)
  {
  };
}
void delays(void)
{
 	//delay(60000);
 	//delay(60000);
 	//delay(60000);
 	//delay(60000);
 	//delay(60000);
 	//delay(60000);
 	//delay(60000);
 	//delay(60000);
 	//delay(60000);
 	delay(60000);
}
/***** routines end ********/